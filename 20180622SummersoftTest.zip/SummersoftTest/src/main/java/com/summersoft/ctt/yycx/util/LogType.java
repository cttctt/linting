package com.summersoft.ctt.yycx.util;

public class LogType {

	public LogType() {

	}

	public enum LogTypeName {

		//
		INFO,
		//
		ERROR,
		//
		WARNING,
		//
		DEBUG;
	}
}
